# human_detect_ever > 2024-05-06 6:52pm
https://universe.roboflow.com/nti-zvemq/human_detect_ever

Provided by a Roboflow user
License: CC BY 4.0

